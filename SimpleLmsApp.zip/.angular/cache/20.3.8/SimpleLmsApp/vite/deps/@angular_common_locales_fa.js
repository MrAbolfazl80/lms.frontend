import "./chunk-6LFTVNYT.js";

// node_modules/@angular/common/locales/fa.js
var u = void 0;
function plural(val) {
  const n = val, i = Math.floor(Math.abs(val));
  if (i === 0 || n === 1)
    return 1;
  return 5;
}
var fa_default = ["fa", [["ق", "ب"], ["ق.ظ.", "ب.ظ."], ["قبل‌ازظهر", "بعدازظهر"]], u, [["ی", "د", "س", "چ", "پ", "ج", "ش"], ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"], u, ["۱ش", "۲ش", "۳ش", "۴ش", "۵ش", "ج", "ش"]], u, [["ژ", "ف", "م", "آ", "م", "ژ", "ژ", "ا", "س", "ا", "ن", "د"], ["ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن", "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"], ["ژانویهٔ", "فوریهٔ", "مارس", "آوریل", "مهٔ", "ژوئن", "ژوئیهٔ", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"]], [["ژ", "ف", "م", "آ", "م", "ژ", "ژ", "ا", "س", "ا", "ن", "د"], ["ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن", "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"]], [["ق", "م"], ["ق.م.", "م."], ["قبل از میلاد", "میلادی"]], 6, [5, 5], ["y/M/d", "d MMM y", "d MMMM y", "EEEE d MMMM y"], ["H:mm", "H:mm:ss", "H:mm:ss (z)", "H:mm:ss (zzzz)"], ["{1}،‏ {0}", u, "{1}، ساعت {0}", u], [".", ",", ";", "%", "‎+", "‎−", "E", "×", "‰", "∞", "ناعدد", ":"], ["#,##0.###", "#,##0%", "‎¤ #,##0.00", "#E0"], "IRR", "ریال", "ریال ایران", { "AFN": ["؋"], "BYN": [u, "р."], "CAD": ["$CA", "$"], "CNY": ["¥CN", "¥"], "HKD": ["$HK", "$"], "IRR": ["ریال"], "MXN": ["$MX", "$"], "NZD": ["$NZ", "$"], "PHP": [u, "₱"], "THB": ["฿"], "XCD": ["$EC", "$"], "XOF": ["فرانک CFA"] }, "rtl", plural];
export {
  fa_default as default
};
/*! Bundled license information:

@angular/common/locales/fa.js:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.dev/license
   *)
*/
//# sourceMappingURL=@angular_common_locales_fa.js.map
