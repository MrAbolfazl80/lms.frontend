// node_modules/ng-zorro-antd/fesm2022/ng-zorro-antd-core-polyfill.mjs
var requestAnimationFrame = typeof globalThis.requestAnimationFrame === "function" ? globalThis.requestAnimationFrame : globalThis.setTimeout;
var cancelAnimationFrame = typeof globalThis.requestAnimationFrame === "function" ? globalThis.cancelAnimationFrame : globalThis.clearTimeout;

export {
  requestAnimationFrame,
  cancelAnimationFrame
};
//# sourceMappingURL=chunk-QYDDKLT3.js.map
