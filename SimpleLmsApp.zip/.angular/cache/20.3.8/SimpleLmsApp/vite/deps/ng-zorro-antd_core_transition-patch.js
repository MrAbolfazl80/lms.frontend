import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-BWSDPYXV.js";
import "./chunk-57WMUKA3.js";
import "./chunk-V37RSN4D.js";
import "./chunk-SR2LXFJL.js";
import "./chunk-VUVMRRXW.js";
import "./chunk-6LFTVNYT.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
