import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-ZJDPUD3T.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-BW3IEXRF.js";
import "./chunk-C2DRZTJX.js";
import "./chunk-ICD623PR.js";
import "./chunk-IUPFJ7CF.js";
import "./chunk-M2XZN42H.js";
import "./chunk-3UBJ4E3J.js";
import "./chunk-XE7NPG3B.js";
import "./chunk-FH6R2WIN.js";
import "./chunk-VFUOCAZJ.js";
import "./chunk-AGCF4D2E.js";
import "./chunk-57WMUKA3.js";
import "./chunk-V37RSN4D.js";
import "./chunk-SR2LXFJL.js";
import "./chunk-VUVMRRXW.js";
import "./chunk-6LFTVNYT.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
